document.addEventListener('DOMContentLoaded', () => {
    fetchSellerProperties();
});

function fetchSellerProperties() {
    // Simulating fetching seller's properties from a server
    const properties = [
        {
            location: 'New York, NY',
            area: 1200,
            bedrooms: 3,
            bathrooms: 2,
            nearbyHospitals: 'Hospital A, Hospital B',
            nearbyColleges: 'College A, College B',
            rentPrice: 2500,
            id: 1
        },
        {
            location: 'San Francisco, CA',
            area: 800,
            bedrooms: 2,
            bathrooms: 1,
            nearbyHospitals: 'Hospital C, Hospital D',
            nearbyColleges: 'College C, College D',
            rentPrice: 3000,
            id: 2
        }
    ];

    const propertyList = document.getElementById('propertyList');
    properties.forEach(property => {
        const propertyElement = document.createElement('div');
        propertyElement.classList.add('property');
        propertyElement.innerHTML = `
            <h3>${property.location}</h3>
            <p>Area: ${property.area} sq ft</p>
            <p>Bedrooms: ${property.bedrooms}</p>
            <p>Bathrooms: ${property.bathrooms}</p>
            <p>Nearby Hospitals: ${property.nearbyHospitals}</p>
            <p>Nearby Colleges: ${property.nearbyColleges}</p>
            <p>Rent Price: $${property.rentPrice}/month</p>
            <button onclick="editProperty(${property.id})">Edit</button>
            <button onclick="deleteProperty(${property.id})">Delete</button>
        `;
        propertyList.appendChild(propertyElement);
    });
}

function editProperty(propertyId) {
    alert(`Edit property ID: ${propertyId}`);
    // Redirect to property edit form or open a modal with property details for editing
}

function deleteProperty(propertyId) {
    if (confirm(`Are you sure you want to delete property ID: ${propertyId}?`)) {
        alert(`Property ID: ${propertyId} has been deleted`);
        // Perform deletion operation and update the property list
    }
}
