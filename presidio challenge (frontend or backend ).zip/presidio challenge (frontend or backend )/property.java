package com.example.rentify.model;

import javax.persistence.*;

@Entity
public class Property {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String location;
    private int area;
    private int bedrooms;
    private int bathrooms;
    private String nearbyHospitals;
    private String nearbyColleges;
    private int rentPrice;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // Getters and Setters
}
